import pathlib
from pathlib import Path
from itertools import islice
import subprocess
# need to avoid
import time
import shutil
import os
# need to avoid
import matplotlib.pyplot as plt
import numpy as np

paths = sorted(Path('.').glob('*.ks'))
file_in_directory = list(map(str, paths))

def cut(marker_start):
    way = str(Path.cwd()) + '\\W2'
    pathlib.Path(way).mkdir(parents=True, exist_ok=True)
    start_xyz = 0
    end_xyz = 0
    index = 0
    for i in file_in_directory:
        name = str(i).replace('.ks', '') +'.txt'
        writing_xyz = open(way + '\\' + name, '+w')
        reading_log = open(i, 'r')
        for line in iter(reading_log):
            index += 1
            if marker_start in line:
                start_xyz = index + 4

        print(start_xyz)
        reading_log.seek(0)
        for found_line in islice(reading_log, start_xyz+1, start_xyz+25):
            writing_xyz.write(found_line)
        index = 0
        start_xyz = 0
        end_xyz = 0
        reading_log.close()
        writing_xyz.close()
    return print('.xyz copied to the XYZ folder')

cut(' Contributions (W2) of functionals to parameters.')