import subprocess
import glob

bat = open('run.bat', '+w')

for file in glob.glob("*.inp"):
    file_out = file.replace('.inp','') + '.ks'
    line = 'UNEX' + '\t' + file + '\t' + file_out + '\t' + '&' + '\n'
    bat.write(line)
bat.close()
#subprocess.Popen('D:\\Bielefeld2021\\Au-complexes\\Au1\\calculation conf from crest\\!unique\\UNEX_COORD\\run.bat')


